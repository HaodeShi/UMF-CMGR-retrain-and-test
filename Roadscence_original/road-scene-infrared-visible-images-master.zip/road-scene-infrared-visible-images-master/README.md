# DATASETS：road-scene-infrared-visible-images 

## Please cite this paper if you use the dataset in this repository as part of a published research project.
@inproceedings{xu2020aaai,
   title={FusionDN: A Unified Densely Connected Network for Image Fusion},
   author={Xu, Han and Ma, Jiayi and Le, Zhuliang and Jiang, Junjun and Guo, Xiaojie},
   booktitle={proceedings of the Thirty-Fourth AAAI Conference on Artificial Intelligence},
   year={2020}
}
